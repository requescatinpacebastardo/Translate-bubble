package com.example.cevirbalon

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class TranslateOverlayService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private var bubble: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    private var panel: View? = null
    private var panelText: TextView? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var panelVisible = false

    private var listPanel: View? = null
    private var listContainer: LinearLayout? = null
    private var listScroll: ScrollView? = null
    private var listParams: WindowManager.LayoutParams? = null
    private var listVisible = false

    private var translator: Translator? = null
    private var translatorPair: Pair<String, String>? = null

    // Ekrandaki mesajlar / OCR paneli için ayrı, ana ayarlardan bağımsız dil çifti
    private var listSrc: String = "es"
    private var listTgt: String = "tr"
    private var listTranslator: Translator? = null
    private var listTranslatorPair: Pair<String, String>? = null
    private var listSrcBtn: TextView? = null
    private var listTgtBtn: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var pendingRunnable: Runnable? = null

    private lateinit var prefs: android.content.SharedPreferences
    private var prefsListener: android.content.SharedPreferences.OnSharedPreferenceChangeListener? = null

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private val overlayType =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("cevir", Context.MODE_PRIVATE)
        listSrc = prefs.getString("src", "tr") ?: "tr"
        listTgt = prefs.getString("tgt", "en") ?: "en"
        startPersistentNotification()
        createBubble()
        createPanel()
        createListPanel()
        applyBubbleVisibility()

        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "bubble_on") applyBubbleVisibility()
        }
        prefsListener = listener
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    // Ana uygulamadaki "balonu göster/gizle" anahtarına göre balonu ve panelleri anında gizler/gösterir.
    private fun applyBubbleVisibility() {
        val on = prefs.getBoolean("bubble_on", true)
        bubble?.visibility = if (on) View.VISIBLE else View.GONE
        if (!on) {
            panelVisible = false
            listVisible = false
            panel?.visibility = View.GONE
            listPanel?.visibility = View.GONE
        }
    }

    private fun startPersistentNotification() {
        val channelId = "ceviri_balon_servis"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Çeviri Balonu", NotificationManager.IMPORTANCE_MIN
            )
            channel.description = "Çeviri balonu arka planda aktif kalır."
            channel.setShowBadge(false)
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
        val notif = Notification.Builder(this, channelId)
            .setContentTitle("Çeviri Balonu aktif")
            .setContentText("Yazarken anında çeviri hazır.")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setOngoing(true)
            .setPriority(Notification.PRIORITY_MIN)
            .build()
        try {
            startForeground(1, notif)
        } catch (_: Exception) { }
    }

    // ---------- Yuvarlak açma/kapama butonu ----------
    // Kısa dokunuş: yazarken otomatik çeviri panelini aç/kapat.
    // Uzun basma: ekrandaki mesajları listele.
    private fun createBubble() {
        val size = dp(38)
        val b = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            scaleType = ImageView.ScaleType.CENTER_CROP
            elevation = dp(4).toFloat()
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setOval(0, 0, size, size)
                }
            }
        }
        val params = WindowManager.LayoutParams(
            size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = dp(16)
        params.y = dp(160)

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        var moved = false; var downTime = 0L
        val longPressMs = 450L

        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = params.x; startY = params.y
                    moved = false
                    downTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    wm.updateViewLayout(b, params)
                    if (panelVisible) repositionPanel()
                    if (listVisible) repositionListPanel()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        val held = System.currentTimeMillis() - downTime
                        if (held >= longPressMs) toggleListPanel() else togglePanel()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    // Oyun gibi yoğun grafik uygulamalarında sistem dokunuşu bazen yarıda kesebiliyor.
                    // Durumu sıfırla ki bir sonraki dokunuş normal çalışsın, panel takılı kalmasın.
                    moved = false
                    true
                }
                else -> false
            }
        }
        wm.addView(b, params)
        bubble = b
        bubbleParams = params
    }

    // ---------- Yazarken otomatik çeviri paneli ----------
    private fun createPanel() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(12))
            val d = GradientDrawable()
            d.cornerRadius = dp(14).toFloat()
            d.setColor(Pal.CARD)
            background = d
            elevation = dp(5).toFloat()
        }
        val headRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val head = TextView(this).apply {
            text = "Çeviri  ·  kısa dokun"
            textSize = 10f
            setTextColor(Pal.MUTED)
        }
        headRow.addView(head, LinearLayout.LayoutParams(0, -2, 1f))
        val closeBtn = TextView(this).apply {
            text = "✕"
            textSize = 13f
            setTextColor(Pal.MUTED)
            setPadding(dp(8), dp(2), dp(2), dp(2))
            setOnClickListener { togglePanel() }
        }
        headRow.addView(closeBtn)
        val body = TextView(this).apply {
            text = "Yazmaya başladığında burada görünecek…"
            textSize = 13f
            setTextColor(Pal.TEXT)
            setLineSpacing(3f, 1f)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, 0)
        }
        val copyBtn = smallButton("Kopyala", Pal.ACCENT, Color.WHITE) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("ceviri", body.text.toString()))
            Toast.makeText(this, "Kopyalandı", Toast.LENGTH_SHORT).show()
        }
        row.addView(copyBtn)
        outer.addView(headRow); outer.addView(body); outer.addView(row)

        val params = WindowManager.LayoutParams(
            dp(190), WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        outer.visibility = View.GONE
        wm.addView(outer, params)
        panel = outer
        panelText = body
        panelParams = params
    }

    private fun repositionPanel() {
        val bp = bubbleParams ?: return
        val pp = panelParams ?: return
        pp.x = bp.x
        pp.y = bp.y + dp(46)
        val view = panel ?: return
        if (!view.isAttachedToWindow) return
        wm.updateViewLayout(view, pp)
        clampPanelOnScreen(view, pp)
    }

    // Panel ekranın alt sınırını aşarsa (balon aşağıda sürüklenmişse), panelin
    // tamamı görünür ve dokunulabilir kalacak şekilde yukarı doğru içeri çeker.
    private fun clampPanelOnScreen(view: View, params: WindowManager.LayoutParams) {
        view.post {
            if (!view.isAttachedToWindow) return@post
            val screenH = resources.displayMetrics.heightPixels
            val screenW = resources.displayMetrics.widthPixels
            val margin = dp(12)
            var changed = false
            if (params.y + view.height > screenH - margin) {
                params.y = (screenH - view.height - margin).coerceAtLeast(margin)
                changed = true
            }
            if (params.x + view.width > screenW - margin) {
                params.x = (screenW - view.width - margin).coerceAtLeast(margin)
                changed = true
            }
            if (changed && view.isAttachedToWindow) wm.updateViewLayout(view, params)
        }
    }

    private fun togglePanel() {
        if (listVisible) toggleListPanel()
        panelVisible = !panelVisible
        panel?.visibility = if (panelVisible) View.VISIBLE else View.GONE
        if (panelVisible) repositionPanel()
    }

    // ---------- Ekrandaki mesajları listeleyen panel ----------
    private fun createListPanel() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(9), dp(8), dp(9), dp(8))
            val d = GradientDrawable()
            d.cornerRadius = dp(12).toFloat()
            d.setColor(Pal.CARD)
            background = d
            elevation = dp(5).toFloat()
        }
        val headRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val head = TextView(this).apply {
            text = "Ekrandaki mesajlar"
            textSize = 10f
            setTextColor(Pal.TEXT)
        }
        val headLp = LinearLayout.LayoutParams(0, -2, 1f)
        headRow.addView(head, headLp)
        val closeBtn = TextView(this).apply {
            text = "✕"
            textSize = 11f
            setTextColor(Pal.MUTED)
            setPadding(dp(6), dp(1), dp(1), dp(1))
            setOnClickListener { toggleListPanel() }
        }
        headRow.addView(closeBtn)
        outer.addView(headRow)

        // Bu panele özel dil çifti: ekranda hangi dil varsa, hangi dile çevrilecek.
        val langRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, dp(2)) }
        fun langBtn(initialCode: String): TextView = TextView(this).apply {
            text = Langs.list.firstOrNull { it.code == initialCode }?.label ?: initialCode
            textSize = 9f
            setTextColor(Pal.TEXT)
            val d = GradientDrawable(); d.cornerRadius = dp(8).toFloat(); d.setColor(Pal.BACKGROUND)
            background = d
            setPadding(dp(7), dp(4), dp(7), dp(4))
        }
        val srcBtn = langBtn(listSrc)
        val arrow = TextView(this).apply {
            text = "→"; textSize = 11f; setTextColor(Pal.MUTED)
            setPadding(dp(4), 0, dp(4), 0)
        }
        val tgtBtn = langBtn(listTgt)
        srcBtn.setOnClickListener { showLangMenu(srcBtn) { code -> listSrc = code; srcBtn.text = labelFor(code); listTranslator = null } }
        tgtBtn.setOnClickListener { showLangMenu(tgtBtn) { code -> listTgt = code; tgtBtn.text = labelFor(code); listTranslator = null } }
        listSrcBtn = srcBtn; listTgtBtn = tgtBtn
        langRow.addView(srcBtn); langRow.addView(arrow); langRow.addView(tgtBtn)
        outer.addView(langRow)

        val toolRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(4)) }
        val refreshBtn = smallButton("Yenile", Pal.ACCENT_SOFT, Pal.TEXT) { scanAndFillList() }
        val ocrBtn = smallButton("📷 Tara", Pal.ACCENT, Color.WHITE) { requestOcrScan() }
        val toolLp = LinearLayout.LayoutParams(0, -2, 1f); toolLp.marginEnd = dp(5)
        toolRow.addView(refreshBtn, toolLp)
        toolRow.addView(ocrBtn, LinearLayout.LayoutParams(0, -2, 1f))
        outer.addView(toolRow)

        val sub = TextView(this).apply {
            text = "Normal tarama bulamazsa \"Tara\"yı dene."
            textSize = 8f
            setTextColor(Pal.MUTED)
            setPadding(0, 0, 0, dp(4))
        }
        outer.addView(sub)

        // Her zaman çalışan yedek yol: metni elle yaz/yapıştır, anında çevir.
        val pasteRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val pasteInput = android.widget.EditText(this).apply {
            hint = "Metni yaz/yapıştır…"
            textSize = 10f
            setTextColor(Pal.TEXT)
            setHintTextColor(Pal.MUTED)
            val d = GradientDrawable(); d.cornerRadius = dp(8).toFloat(); d.setColor(Pal.BACKGROUND)
            background = d
            setPadding(dp(8), dp(4), dp(8), dp(4))
            maxLines = 2
        }
        val pasteBtn = TextView(this).apply {
            text = "⇄"
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            val d = GradientDrawable(); d.shape = GradientDrawable.OVAL; d.setColor(Pal.ACCENT)
            background = d
        }
        val pasteBtnSize = dp(22)
        val pasteBtnLp = LinearLayout.LayoutParams(pasteBtnSize, pasteBtnSize); pasteBtnLp.marginStart = dp(5)
        pasteBtn.setOnClickListener {
            val t = pasteInput.text.toString().trim()
            if (t.isEmpty()) return@setOnClickListener
            val container = listContainer ?: return@setOnClickListener
            container.removeAllViews()
            val row = buildMessageRow(t)
            container.addView(row)
            pasteInput.text.clear()
        }
        pasteRow.addView(pasteInput, LinearLayout.LayoutParams(0, -2, 1f))
        pasteRow.addView(pasteBtn, pasteBtnLp)
        outer.addView(pasteRow)
        val pasteSpacer = TextView(this).apply { setPadding(0, 0, 0, dp(4)) }
        outer.addView(pasteSpacer)

        val scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(-1, dp(220))
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        scroll.addView(container)
        outer.addView(scroll)

        val params = WindowManager.LayoutParams(
            dp(180), WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        outer.visibility = View.GONE
        wm.addView(outer, params)
        listPanel = outer
        listContainer = container
        listScroll = scroll
        listParams = params
    }

    private fun repositionListPanel() {
        val bp = bubbleParams ?: return
        val pp = listParams ?: return
        val view = listPanel ?: return
        if (!view.isAttachedToWindow) return

        pp.x = bp.x
        // Panelin üstü ekranın dışına taşmasın
        val screenH = resources.displayMetrics.heightPixels
        val margin = dp(16)
        pp.y = (bp.y + dp(46)).coerceAtMost(screenH - dp(120))

        // Liste kutusunun yüksekliğini, o konumda ekranda kalan gerçek boşluğa göre ayarla.
        // "chrome" = başlık + dil satırı + araç satırı + açıklama + yapıştır satırı (yaklaşık sabit).
        val chromeHeight = dp(125)
        val available = (screenH - pp.y - chromeHeight - margin).coerceIn(dp(100), dp(520))
        listScroll?.layoutParams = LinearLayout.LayoutParams(-1, available)
        listScroll?.requestLayout()

        wm.updateViewLayout(view, pp)
    }

    private fun toggleListPanel() {
        if (panelVisible) togglePanel()
        listVisible = !listVisible
        listPanel?.visibility = if (listVisible) View.VISIBLE else View.GONE
        if (listVisible) {
            repositionListPanel()
            scanAndFillList()
        }
    }

    // Ekrandaki aktif pencereyi tarayıp görünen metinleri toplar.
    private fun scanAndFillList() {
        val container = listContainer ?: return
        container.removeAllViews()
        val root = rootInActiveWindow
        if (root == null) {
            container.addView(infoRow("Ekran okunamadı, tekrar dene."))
            return
        }
        val texts = LinkedHashSet<String>()
        collectTexts(root, texts)
        if (texts.isEmpty()) {
            container.addView(infoRow("Görünen yazı bulunamadı."))
            return
        }
        texts.take(30).forEach { t -> container.addView(buildMessageRow(t)) }
    }

    private fun collectTexts(node: AccessibilityNodeInfo, out: MutableSet<String>) {
        if (out.size >= 60) return
        val t = node.text?.toString()?.trim()
        if (!t.isNullOrEmpty() && t.length in 1..300) out.add(t)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectTexts(child, out)
            child.recycle()
        }
    }

    // ---------- OCR: ekran görüntüsünden yazı okuma (oyunlar için) ----------
    // AccessibilityService.takeScreenshot: Android 11+ sistem API'si, izin ekranı göstermez,
    // kullanıcıyı uygulamadan çıkarmaz, mevcut erişilebilirlik iznini kullanır.
    private fun requestOcrScan() {
        val container = listContainer ?: return
        container.removeAllViews()

        if (Build.VERSION.SDK_INT < 30) {
            container.addView(infoRow("Bu özellik Android 11 ve üstü gerektiriyor."))
            return
        }
        container.addView(infoRow("Ekran taranıyor…"))

        // Ekran görüntüsüne kendi arayüzümüz (balon + paneller) girmesin diye
        // anlık olarak gizliyoruz; konumları değişmiyor, sadece görünürlük kapanıyor.
        val wasBubbleVisible = bubble?.visibility == View.VISIBLE
        val wasPanelVisible = panelVisible
        val wasListVisible = listVisible
        bubble?.visibility = View.GONE
        panel?.visibility = View.GONE
        listPanel?.visibility = View.GONE

        fun restoreOverlays() {
            if (wasBubbleVisible) bubble?.visibility = View.VISIBLE
            if (wasPanelVisible) panel?.visibility = View.VISIBLE
            if (wasListVisible) listPanel?.visibility = View.VISIBLE
        }

        // Görünürlük değişikliğinin ekrana gerçekten yansıması için kısa bir an bekliyoruz.
        handler.postDelayed({
            try {
                takeScreenshot(
                    android.view.Display.DEFAULT_DISPLAY,
                    mainExecutor,
                    object : TakeScreenshotCallback {
                        override fun onSuccess(result: ScreenshotResult) {
                            restoreOverlays()
                            try {
                                val hw = result.hardwareBuffer
                                val bmpHw = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                                val bmp = bmpHw?.copy(Bitmap.Config.ARGB_8888, false)
                                hw.close()
                                if (bmp != null) runTextRecognition(bmp)
                                else showListError("Görüntü alınamadı.")
                            } catch (e: Exception) {
                                showListError("Görüntü işlenemedi.")
                            }
                        }

                        override fun onFailure(errorCode: Int) {
                            restoreOverlays()
                            showListError("Ekran okunamadı (hata kodu $errorCode).")
                        }
                    }
                )
            } catch (e: Exception) {
                restoreOverlays()
                showListError("Bu cihazda ekran tarama desteklenmiyor.")
            }
        }, 150)
    }

    private fun showListError(msg: String) {
        handler.post {
            val container = listContainer ?: return@post
            container.removeAllViews()
            container.addView(infoRow(msg))
        }
    }

    // Bir OCR bloğunun satırlarını birleştirip cümle/paragraf haline getirir.
    // Satır sonu bir "kaydırma" ise sonraki satırla birleştirilir, gerçek mesaj
    // sınırıysa yeni paragraf başlar (bkz. isHardBreak). Noktalamaya güvenmez.
    private fun blockToParagraphs(block: Text.TextBlock): List<String> {
        val lines = block.lines.filter { it.text.isNotBlank() }
        if (lines.isEmpty()) return emptyList()
        if (lines.size == 1) return listOf(lines[0].text.trim())

        val maxRight = lines.maxOf { it.boundingBox?.right ?: 0 }
        val minLeft = lines.minOf { it.boundingBox?.left ?: 0 }
        val blockWidth = (maxRight - minLeft).coerceAtLeast(1)
        val hasBoxes = lines.all { it.boundingBox != null }

        val out = ArrayList<String>()
        val cur = StringBuilder()
        for ((i, line) in lines.withIndex()) {
            val t = line.text.trim()
            if (cur.isEmpty()) {
                cur.append(t)
            } else if (cur.endsWith("-") && t.firstOrNull()?.isLowerCase() == true) {
                // satır sonu tire ile bölünmüş kelime
                cur.setLength(cur.length - 1)
                cur.append(t)
            } else {
                cur.append(' ').append(t)
            }
            if (i == lines.lastIndex) break
            if (hasBoxes && isHardBreak(line, lines[i + 1], t, lines[i + 1].text.trim(), minLeft, maxRight, blockWidth)) {
                out.add(cur.toString()); cur.setLength(0)
            }
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    // İki satır arasında "yeni mesaj" sınırı var mı? Noktalamaya bakmaz, sadece konuma bakar:
    // 1) Satırlar arası boşluk normal satır aralığından belirgin büyükse
    // 2) Satır sol kenarı kayıyorsa (farklı hizalama / girinti)
    // 3) Satır bloğun genişliğini doldurmuyorsa (kaydırılan satırlar hep dolu olur)
    // 4) Sonraki satırın ilk kelimesi önceki satırın sonuna sığabilecekken alta geçmişse
    private fun isHardBreak(
        a: Text.Line, b: Text.Line, aText: String, bText: String,
        minLeft: Int, maxRight: Int, blockWidth: Int
    ): Boolean {
        val ab = a.boundingBox ?: return false
        val bb = b.boundingBox ?: return false
        val lineH = ab.height().coerceAtLeast(1)

        val gap = bb.top - ab.bottom
        if (gap > lineH * 0.8f) return true

        if (Math.abs(bb.left - ab.left) > lineH * 1.5f) return true

        val filled = (ab.right - minLeft).toFloat() / blockWidth
        if (filled < 0.75f) return true

        val nextWord = bText.substringBefore(' ')
        if (aText.isNotEmpty() && nextWord.isNotEmpty()) {
            val avgChar = ab.width().toFloat() / aText.length
            val remaining = maxRight - ab.right
            if (remaining >= avgChar * (nextWord.length + 1) * 1.1f) return true
        }
        return false
    }

    private fun runTextRecognition(bitmap: Bitmap) {
        val input = InputImage.fromBitmap(bitmap, 0)
        textRecognizer.process(input)
            .addOnSuccessListener { result ->
                val container = listContainer
                container?.removeAllViews()
                val paragraphs = LinkedHashSet<String>()
                // Üstten alta, sonra soldan sağa sırala (okuma sırası)
                val blocks = result.textBlocks.sortedWith(
                    compareBy({ it.boundingBox?.top ?: 0 }, { it.boundingBox?.left ?: 0 })
                )
                for (block in blocks) {
                    for (p in blockToParagraphs(block)) {
                        if (p.length in 1..600) paragraphs.add(p)
                    }
                }
                if (paragraphs.isEmpty()) {
                    container?.addView(infoRow("Ekranda okunabilir yazı bulunamadı."))
                } else {
                    paragraphs.take(30).forEach { t -> container?.addView(buildMessageRow(t)) }
                }
            }
            .addOnFailureListener {
                val container = listContainer
                container?.removeAllViews()
                container?.addView(infoRow("Ekran okunamadı, tekrar dene."))
            }
    }

    private fun labelFor(code: String): String = Langs.list.firstOrNull { it.code == code }?.label ?: code

    private fun showLangMenu(anchor: View, onPick: (String) -> Unit) {
        val menu = PopupMenu(this, anchor)
        Langs.list.forEach { l -> menu.menu.add(l.label) }
        menu.setOnMenuItemClickListener { item ->
            val lang = Langs.list.firstOrNull { it.label == item.title.toString() }
            if (lang != null) onPick(lang.code)
            true
        }
        menu.show()
    }

    private fun ensureListTranslator(onReady: () -> Unit) {
        if (listTranslator != null && listTranslatorPair == Pair(listSrc, listTgt)) {
            onReady(); return
        }
        listTranslator?.close()
        val opts = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.fromLanguageTag(listSrc) ?: TranslateLanguage.TURKISH)
            .setTargetLanguage(TranslateLanguage.fromLanguageTag(listTgt) ?: TranslateLanguage.ENGLISH)
            .build()
        listTranslator = Translation.getClient(opts)
        listTranslatorPair = Pair(listSrc, listTgt)
        listTranslator?.downloadModelIfNeeded()
            ?.addOnSuccessListener { onReady() }
            ?.addOnFailureListener { Toast.makeText(this, "Dil paketi indirilemedi (internet gerekli).", Toast.LENGTH_SHORT).show() }
    }

    private fun doListTranslate(text: String, onResult: (String) -> Unit) {
        listTranslator?.translate(text)
            ?.addOnSuccessListener { result -> onResult(result) }
            ?.addOnFailureListener { onResult("Çeviri yapılamadı.") }
    }

    private fun infoRow(msg: String): View = TextView(this).apply {
        text = msg
        textSize = 13f
        setTextColor(Pal.MUTED)
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun buildMessageRow(original: String): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val d = GradientDrawable()
            d.cornerRadius = dp(10).toFloat()
            d.setColor(Pal.BACKGROUND)
            background = d
            setPadding(dp(8), dp(6), dp(8), dp(6))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(6)
            layoutParams = lp
        }
        val topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val orig = TextView(this).apply {
            text = original
            textSize = 11f
            setTextColor(Pal.TEXT)
            maxLines = 8
        }
        val origLp = LinearLayout.LayoutParams(0, -2, 1f)
        topRow.addView(orig, origLp)

        val result = TextView(this).apply {
            textSize = 11f
            setTextColor(Pal.ACCENT)
            setPadding(0, dp(4), 0, 0)
            visibility = View.GONE
        }

        // Argo/yazım hatalı cümlelerde cihaz-içi model yetersiz kalabilir; gerekirse
        // gerçek Google Translate'i (internetli, çok daha güçlü) tarayıcıda açan yedek yol.
        val googleBtn = TextView(this).apply {
            text = "🌐 Google'da aç"
            textSize = 8f
            setTextColor(Pal.MUTED)
            setPadding(0, dp(3), 0, 0)
            visibility = View.GONE
            setOnClickListener {
                try {
                    val encoded = java.net.URLEncoder.encode(original, "UTF-8")
                    val url = "https://translate.google.com/?sl=auto&tl=$listTgt&text=$encoded&op=translate"
                    val i = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } catch (e: Exception) {
                    Toast.makeText(this@TranslateOverlayService, "Tarayıcı açılamadı.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val transBtn = TextView(this).apply {
            text = "⇄"
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            val d = GradientDrawable(); d.shape = GradientDrawable.OVAL; d.setColor(Pal.ACCENT)
            background = d
        }
        val btnSize = dp(20)
        val btnLp = LinearLayout.LayoutParams(btnSize, btnSize)
        btnLp.marginStart = dp(6)
        transBtn.setOnClickListener {
            result.text = "Çevriliyor…"
            result.visibility = View.VISIBLE
            googleBtn.visibility = View.VISIBLE
            ensureListTranslator {
                doListTranslate(original) { r -> result.text = r }
            }
        }
        topRow.addView(transBtn, btnLp)

        card.addView(topRow)
        card.addView(result)
        card.addView(googleBtn)

        card.setOnLongClickListener {
            if (result.visibility == View.VISIBLE) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("ceviri", result.text.toString()))
                Toast.makeText(this, "Kopyalandı", Toast.LENGTH_SHORT).show()
            }
            true
        }
        return card
    }

    private fun smallButton(text: String, bg: Int, fg: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 12f
        b.setTextColor(fg)
        val d = GradientDrawable(); d.cornerRadius = dp(14).toFloat(); d.setColor(bg)
        b.background = d
        b.setPadding(dp(16), dp(6), dp(16), dp(6))
        b.minHeight = 0
        b.minimumHeight = 0
        b.setOnClickListener { onClick() }
        return b
    }

    // ---------- Metin izleme ve çeviri (yazarken otomatik) ----------
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!panelVisible) return
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) return
        val text = e.text?.joinToString(" ")?.trim().orEmpty()
        if (text.isEmpty()) return

        pendingRunnable?.let { handler.removeCallbacks(it) }
        val r = Runnable {
            ensureTranslator {
                doTranslate(text) { result -> panelText?.text = result }
            }
        }
        pendingRunnable = r
        handler.postDelayed(r, 350)
    }

    private fun ensureTranslator(onReady: () -> Unit) {
        val prefs = getSharedPreferences("cevir", Context.MODE_PRIVATE)
        val src = prefs.getString("src", "tr") ?: "tr"
        val tgt = prefs.getString("tgt", "en") ?: "en"

        if (translator != null && translatorPair == Pair(src, tgt)) {
            onReady(); return
        }
        translator?.close()
        val opts = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.fromLanguageTag(src) ?: TranslateLanguage.TURKISH)
            .setTargetLanguage(TranslateLanguage.fromLanguageTag(tgt) ?: TranslateLanguage.ENGLISH)
            .build()
        translator = Translation.getClient(opts)
        translatorPair = Pair(src, tgt)
        panelText?.text = "Dil paketi hazırlanıyor…"
        translator?.downloadModelIfNeeded()
            ?.addOnSuccessListener { onReady() }
            ?.addOnFailureListener { panelText?.text = "İndirme başarısız, internet gerekli (ilk sefer)." }
    }

    private fun doTranslate(text: String, onResult: (String) -> Unit) {
        translator?.translate(text)
            ?.addOnSuccessListener { result -> onResult(result) }
            ?.addOnFailureListener { onResult("Çeviri yapılamadı.") }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        prefsListener?.let { prefs.unregisterOnSharedPreferenceChangeListener(it) }
        bubble?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        listPanel?.let { runCatching { wm.removeView(it) } }
        translator?.close()
        listTranslator?.close()
        textRecognizer.close()
    }
}
