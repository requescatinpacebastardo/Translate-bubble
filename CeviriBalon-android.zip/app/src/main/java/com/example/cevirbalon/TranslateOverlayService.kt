package com.example.cevirbalon

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

class TranslateOverlayService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var panelText: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var panelVisible = false
    private var translator: Translator? = null
    private var translatorPair: Pair<String, String>? = null
    private val handler = Handler(Looper.getMainLooper())
    private var pendingRunnable: Runnable? = null

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private val overlayType =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createBubble()
        createPanel()
    }

    // ---------- Yuvarlak açma/kapama butonu ----------
    private fun createBubble() {
        val b = TextView(this).apply {
            text = "⇄"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            d.setColor(Pal.ACCENT)
            background = d
            elevation = dp(4).toFloat()
        }
        val size = dp(52)
        val params = WindowManager.LayoutParams(
            size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = dp(16)
        params.y = dp(160)

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = params.x; startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    wm.updateViewLayout(b, params)
                    panel?.let { repositionPanel() }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    true
                }
                else -> false
            }
        }
        wm.addView(b, params)
        bubble = b
        bubbleParams = params
    }

    // ---------- Çeviri paneli ----------
    private fun createPanel() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(16))
            val d = GradientDrawable()
            d.cornerRadius = dp(18).toFloat()
            d.setColor(Pal.CARD)
            background = d
            elevation = dp(6).toFloat()
        }
        val head = TextView(this).apply {
            text = "Çeviri"
            textSize = 12f
            setTextColor(Pal.MUTED)
            setPadding(0, 0, 0, dp(8))
        }
        val body = TextView(this).apply {
            text = "Yazmaya başladığında burada görünecek…"
            textSize = 15f
            setTextColor(Pal.TEXT)
            setLineSpacing(4f, 1f)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }
        val copyBtn = Button(this).apply {
            text = "Kopyala"
            isAllCaps = false
            setTextColor(Color.WHITE)
            val d = GradientDrawable(); d.cornerRadius = dp(14).toFloat(); d.setColor(Pal.ACCENT)
            background = d
            setPadding(dp(20), dp(10), dp(20), dp(10))
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("ceviri", body.text.toString()))
                Toast.makeText(this@TranslateOverlayService, "Kopyalandı", Toast.LENGTH_SHORT).show()
            }
        }
        row.addView(copyBtn)
        outer.addView(head); outer.addView(body); outer.addView(row)

        val params = WindowManager.LayoutParams(
            dp(240), WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        outer.visibility = View.GONE
        wm.addView(outer, params)
        panel = outer
        panelText = body
        panelParams = params
    }

    private fun repositionPanel() {
        val bp = bubbleParams ?: return
        val pp = panelParams ?: return
        pp.x = bp.x
        pp.y = bp.y + dp(60)
        panel?.let { if (it.isAttachedToWindow) wm.updateViewLayout(it, pp) }
    }

    private fun togglePanel() {
        panelVisible = !panelVisible
        panel?.visibility = if (panelVisible) View.VISIBLE else View.GONE
        if (panelVisible) repositionPanel()
    }

    // ---------- Metin izleme ve çeviri ----------
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!panelVisible) return
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) return
        val text = e.text?.joinToString(" ")?.trim().orEmpty()
        if (text.isEmpty()) return

        pendingRunnable?.let { handler.removeCallbacks(it) }
        val r = Runnable { translateAndShow(text) }
        pendingRunnable = r
        handler.postDelayed(r, 350) // kullanıcı yazmayı bitirsin diye kısa gecikme
    }

    private fun translateAndShow(text: String) {
        val prefs = getSharedPreferences("cevir", Context.MODE_PRIVATE)
        val src = prefs.getString("src", "tr") ?: "tr"
        val tgt = prefs.getString("tgt", "en") ?: "en"

        if (translator == null || translatorPair != Pair(src, tgt)) {
            translator?.close()
            val opts = TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.fromLanguageTag(src) ?: TranslateLanguage.TURKISH)
                .setTargetLanguage(TranslateLanguage.fromLanguageTag(tgt) ?: TranslateLanguage.ENGLISH)
                .build()
            translator = Translation.getClient(opts)
            translatorPair = Pair(src, tgt)
            panelText?.text = "Dil paketi hazırlanıyor…"
            translator?.downloadModelIfNeeded()
                ?.addOnSuccessListener { doTranslate(text) }
                ?.addOnFailureListener { panelText?.text = "İndirme başarısız, internet gerekli (ilk sefer)." }
        } else {
            doTranslate(text)
        }
    }

    private fun doTranslate(text: String) {
        translator?.translate(text)
            ?.addOnSuccessListener { result -> panelText?.text = result }
            ?.addOnFailureListener { panelText?.text = "Çeviri yapılamadı." }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        bubble?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        translator?.close()
    }
}
