package com.example.cevirbalon

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle

/**
 * Android'in "ekranı kaydet/yansıt" izin ekranını açıp sonucu servise iletir.
 * Hiçbir arayüzü yoktur, görünmeden açılıp kapanır.
 */
class ScreenCaptureConsentActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        try {
            startActivityForResult(mgr.createScreenCaptureIntent(), 500)
        } catch (e: Exception) {
            TranslateOverlayService.pendingCaptureCallback?.invoke(RESULT_CANCELED, null)
            TranslateOverlayService.pendingCaptureCallback = null
            finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        TranslateOverlayService.pendingCaptureCallback?.invoke(resultCode, data)
        TranslateOverlayService.pendingCaptureCallback = null
        finish()
        overridePendingTransition(0, 0)
    }
}
